<?php include('server.php');

if(isset($_SESSION["Username"])){
    $username=$_SESSION["Username"];
    if ($_SESSION["Usertype"]==1) {
        $linkPro="freelancerProfile.php";
        $linkEditPro="editFreelancer.php";
    } else {
        $linkPro="employerProfile.php";
        $linkEditPro="editEmployer.php";
    }
} else {
    // Guest user logic
    if(!isset($_SESSION['guest_username'])){
        $_SESSION['guest_username'] = generateGuestUsername($conn);
    }
    $username = $_SESSION['guest_username'];
    $linkPro = "guestProfile.php";
    $linkEditPro = "";
}

// Fetch list of contacts with the last message
$sql = "SELECT sender, receiver, msg, timestamp FROM message 
        WHERE sender='$username' OR receiver='$username' 
        GROUP BY LEAST(sender, receiver), GREATEST(sender, receiver) 
        ORDER BY timestamp DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Messages</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css">
    <link rel="stylesheet" type="text/css" href="awesome/css/fontawesome-all.min.css">
</head>
<body>

<!--Navbar menu-->
<nav class="navbar navbar-inverse navbar-fixed-top" id="my-navbar">
    <div class="container">
        <div class="navber-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand">Freelance Marketplace</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="allJob.php">Browse all jobs</a></li>
                <li><a href="allFreelancer.php">Browse Freelancers</a></li>
                <li><a href="allEmployer.php">Browse Employers</a></li>
                <li class="dropdown" style="background:#000;padding:0 20px 0 20px;">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="guest_profile.php"><span class="glyphicon glyphicon-user"></span> <?php echo $username; ?>
                    </a>
                    <ul class="dropdown-menu list-group list-group-item-info">
                        <a href="<?php echo $linkPro; ?>" class="list-group-item"><span class="glyphicon glyphicon-home"></span>  View profile</a>
                        <?php if($linkEditPro): ?>
                        <a href="<?php echo $linkEditPro; ?>" class="list-group-item"><span class="glyphicon glyphicon-inbox"></span>  Edit Profile</a>
                        <?php endif; ?>
                        <a href="message.php" class="list-group-item"><span class="glyphicon glyphicon-envelope"></span>  Messages</a> 
                        <a href="logout.php" class="list-group-item"><span class="glyphicon glyphicon-ok"></span>  Logout</a>
                    </ul>
                </li>
            </ul>
        </div>      
    </div>  
</nav>
<!--End Navbar menu-->

<!--main body-->
<div style="padding:1% 3% 1% 3%;">
<div class="row">

<!--Message List Column-->
    <div class="col-lg-9">

<!--Message List-->    
        <div class="card" style="padding:20px 20px 5px 20px;margin-top:20px">
            <div class="panel panel-success">
              <div class="panel-heading"><h3>Message History</h3></div>
              <div class="panel-body">
                  <table style="width:100%">
                      <tr>
                          <th>Username</th>
                          <th>Last Message</th>
                          <th>Timestamp</th>
                      </tr>
                      <?php
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                $contactUser = $row["sender"] == $username ? $row["receiver"] : $row["sender"];
                                $lastMsg = $row["msg"];
                                $timestamp = $row["timestamp"];

                                echo '
                                <tr>
                                    <td><a href="chatbox.php?user='.$contactUser.'">'.$contactUser.'</a></td>
                                    <td>'.$lastMsg.'</td>
                                    <td>'.$timestamp.'</td>
                                </tr>';
                            }
                        } else {
                            echo "<tr><td colspan='3'>No messages to show</td></tr>";
                        }
                       ?>
                     </table>
              </div>
            </div>
        </div>
<!--End Message List-->

    </div>
<!--End Message List Column-->
</div>
</div>
<!--End main body-->

<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>

</body>
</html>
