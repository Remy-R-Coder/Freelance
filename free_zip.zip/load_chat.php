<?php
// Include your server connection and session start
include('server.php');

// Check if the user is logged in and the `user` parameter is set
if (isset($_GET['user']) && isset($_SESSION['Username'])) {
    $contactUser = $_GET['user'];
    $username = $_SESSION['Username'];

    // SQL query to fetch chat messages between the two users
    $sql = "SELECT sender, receiver, msg, timestamp FROM message 
            WHERE (sender='$username' AND receiver='$contactUser') 
            OR (sender='$contactUser' AND receiver='$username')
            ORDER BY timestamp ASC";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            // Determine if the message is sent or received
            $messageClass = ($row['sender'] == $username) ? 'right-message' : 'left-message';

            echo '<div class="message-container '.$messageClass.'">';
            echo '    <div class="profile">' . htmlspecialchars(substr(($row['sender'] == $username) ? $username : $contactUser, 0, 1)) . '</div>';
            echo '    <div class="message-content">';
            echo '        <p>' . htmlspecialchars($row['msg']) . '</p>';
            echo '        <small class="message-time">' . formatTimestamp($row['timestamp']) . '</small>';
            echo '    </div>';
            echo '</div>';
        }
    } else {
        echo '<p>No messages found.</p>';
    }
} else {
    echo '<p>Invalid request.</p>';
}
?>
