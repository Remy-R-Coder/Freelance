<?php 
include('server.php');

if (isset($_SESSION["Username"])) {
    $username = $_SESSION["Username"];
    $usertype = $_SESSION["Usertype"];
    
    if ($usertype == 1) { // Freelancer
        $linkPro = "freelancerProfile.php";
        $linkEditPro = "editFreelancer.php";
        $linkBtn = "applyJob.php";
        $textBtn = "Apply for this job";
    } elseif ($usertype == 2) { // Employer
        $linkPro = "employerProfile.php";
        $linkEditPro = "editEmployer.php";
        $linkBtn = "editJob.php";
        $textBtn = "Edit the job offer";
    }
} elseif (isset($_SESSION['guest_username'])) { // Guest
    $username = $_SESSION['guest_username'];
    $linkPro = "guestProfile.php";
    $linkEditPro = "#"; // No edit profile for guest, can adjust this as needed
    $linkBtn = ""; // No specific button for guests
    $textBtn = "";
} else {
    $username = "";
}

if (isset($_POST["jid"])) {
    $_SESSION["job_id"] = $_POST["jid"];
    header("location: jobDetails.php");
}

// Default SQL query to fetch all valid job offers
$sql = "SELECT * FROM job_offer WHERE valid=1 ORDER BY job_id DESC";

if (isset($_POST["s_type"]) && !empty($_POST["s_type"])) {
    $t = test_input($_POST["s_type"]);
    // SQL query to filter job offers based on the selected type
    $sql = "SELECT * FROM job_offer WHERE type='$t' AND valid=1 ORDER BY job_id DESC";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Job Offers</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css">
    <link rel="stylesheet" type="text/css" href="awesome/css/fontawesome-all.min.css">
    <style>
        body { padding-top: 3%; margin: 0; }
        .card { box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); background: #fff; }
        .gig-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .gig-card {
            flex: 1 1 calc(33.33% - 20px);
            box-sizing: border-box;
            max-width: calc(33.33% - 20px);
            margin-bottom: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
        }
        .gig-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .gig-card-content {
            padding: 10px;
            text-align: center;
        }
        .gig-card-content h4 {
            margin: 10px 0;
            font-size: 18px;
        }
        .gig-card-content p {
            margin: 0;
        }
    </style>
</head>
<body>

<!--Navbar menu-->
<nav class="navbar navbar-inverse navbar-fixed-top" id="my-navbar">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand">RemyInk!</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="exams_quizzes.php">Exams & Quizzes</a></li>  <!-- New link -->
                <li><a href="research_essays.php">Research & Essays</a></li>  <!-- New link -->
                <li><a href="tutoring.php">Tutoring</a></li>  <!-- New link -->
                <li class="dropdown" style="background:#000;padding:0 20px 0 20px;">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <span class="glyphicon glyphicon-user"></span> <?php echo $username; ?>
                    </a>
                    <ul class="dropdown-menu list-group list-group-item-info">
                        <a href="guest_profile.php" class="list-group-item"><span class="glyphicon glyphicon-home"></span> View profile</a>
                        <?php if ($usertype != 3) { ?>
                        <?php } ?>
                        <a href="message.php" class="list-group-item"><span class="glyphicon glyphicon-envelope"></span> Messages</a>
                        <a href="index.php" class="list-group-item"><span class="glyphicon glyphicon-ok"></span> Logout</a>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!--End Navbar menu-->

<div class="container">
    <div class="row">
        <div class="col-lg-9">
            <!-- Job Offers List -->
            <div class="card" style="padding:20px 20px 5px 20px;margin-top:20px">
                <div class="panel panel-success">
                    <div class="panel-heading"><h3>Services Offerings</h3></div>
                    <div class="panel-body">
                        <div class="gig-container">
                            <?php 
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $title = $row["title"];
                                    $type = $row["type"];
                                    $description = $row["description"];
                                    $e_username = $row["e_username"];
                                    $image = "https://st2.depositphotos.com/1444927/6033/i/450/depositphotos_60339431-stock-photo-test-time.jpg"; // Example image URL

                                    echo '
                                    <div class="gig-card">
                                        <img src="'.$image.'" alt="Gig Image">
                                        <div class="gig-card-content">
                                            <h4>'.$title.'</h4>
                                            <p><strong>Type:</strong> '.$type.'</p>
                                            <p>'.$description.'</p>
                                            <p><strong>Username:</strong> '.$e_username.'</p>
                                            <form action="allJob.php" method="post">
                                                <input type="hidden" name="jid" value="'.$row["job_id"].'">
                                                <button type="submit" class="btn btn-primary">View Details</button>
                                            </form>
                                        </div>
                                    </div>
                                    ';
                                }
                            } else {
                                echo "<p>No jobs available.</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Job Offers List -->
        </div>

        <div class="col-lg-3">
            <!-- Search Filters -->
            <div class="card" style="padding:20px 20px 5px 20px;margin-top:20px">
                <form action="allJob.php" method="post">
                    <div class="form-group">
                        <select class="form-control" name="s_type">
                            <option value="">Select Job Type</option>
                            <option value="Exams/Quizzes">Exams & Quizzes</option>
                            <option value="Research/Essays">Research & Essays</option>
                            <option value="Tutoring">Tutoring</option>
                        </select>
                        <center><button type="submit" class="btn btn-info">Search by Job Type</button></center>
                    </div>
                </form>
            </div>
            <!-- End Search Filters -->
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
