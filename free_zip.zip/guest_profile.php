<?php
include('server.php');

// Check if the guest username exists in the session
if(isset($_SESSION['guest_username'])){
    $username = $_SESSION['guest_username'];
} else {
    // Redirect to the home page if no guest profile is found
    header("location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Client Profile</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css">
    <link rel="stylesheet" type="text/css" href="awesome/css/fontawesome-all.min.css">
    <style>
        body { padding-top: 3%; margin: 0; }
        .card { box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); background:#fff; }
    </style>
</head>
<body>

<!--Navbar menu-->
<nav class="navbar navbar-inverse navbar-fixed-top" id="my-navbar">
    <div class="container">
        <div class="navbar-header"> <!-- Corrected class name -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand">RemyInk!</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="allJob.php">Browse all jobs</a></li>
                <li class="dropdown" style="background:#000;padding:0 20px 0 20px;">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <span class="glyphicon glyphicon-user"></span> <?php echo $username; ?>
                    </a>
                    <ul class="dropdown-menu list-group list-group-item-info">
                        <li><a href="index.php" class="list-group-item"><span class="glyphicon glyphicon-ok"></span> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>      
    </div>  
</nav>
<!--End Navbar menu-->

<!--Main body-->
<div style="padding:1% 3% 1% 3%;">
    <div class="row">

    <!--Column 1-->
        <div class="col-lg-9">

    <!--Guest Profile Details-->    
            <div class="card" style="padding:20px 20px 5px 20px;margin-top:20px">
                <div class="panel panel-success">
                  <div class="panel-heading"><h3>Guest Profile</h3></div>
                  <div class="panel-body"><h4>
                      <p><strong>Username:</strong> <?php echo $username; ?></p>
                  </h4></div>
                </div>
            </div>
    <!--End Guest Profile Details-->

        </div>
    <!--End Column 1-->

    <!--Column 2-->
        <div class="col-lg-3">

    <!--Main profile card-->
            <div class="card" style="padding:20px 20px 5px 20px;margin-top:20px">
                <p></p>
                <form action="message.php" method="post">
                    <div class="form-group">
                      <center><button type="submit" name="inbox" class="btn btn-info">View Messages</button></center>
                    </div>
                </form>
            </div>
    <!--End Main profile card-->

        </div>
    <!--End Column 2-->
    </div>
</div>
<!--End main body-->

<!-- Include jQuery before Bootstrap's JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>

</body>
</html>
