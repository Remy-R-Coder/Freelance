<?php 
include('server.php');

if (isset($_SESSION["Username"])) {
    $username = $_SESSION["Username"];
    $usertype = $_SESSION["Usertype"];
    
    if ($usertype == 1) {
        $linkPro = "freelancerProfile.php";
        $linkEditPro = "editFreelancer.php";
        $linkBtn = "applyJob.php";
        $textBtn = "Apply for this job";
    } else {
        $linkPro = "employerProfile.php";
        $linkEditPro = "editEmployer.php";
        $linkBtn = "editJob.php";
        $textBtn = "Edit the job offer";
    }
} else {
    $username = "";
}

if (isset($_POST["jid"])) {
    $_SESSION["job_id"] = $_POST["jid"];
    header("location: jobDetails.php");
}

// SQL query to fetch only "Exams & Quizzes" gigs
$sql = "SELECT * FROM job_offer WHERE type='Tutoring' AND valid=1 ORDER BY job_id DESC";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html>
<head>
    <title>Tutoring Gigs</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css">
    <link rel="stylesheet" type="text/css" href="awesome/css/fontawesome-all.min.css">
    <style>
        body { padding-top: 3%; margin: 0; }
        .card { box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); background: #fff; }
        .gig-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .gig-card {
            flex: 1 1 calc(33.33% - 20px);
            box-sizing: border-box;
            max-width: calc(33.33% - 20px);
            margin-bottom: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
        }
        .gig-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .gig-card-content {
            padding: 10px;
            text-align: center;
        }
        .gig-card-content h4 {
            margin: 10px 0;
            font-size: 18px;
        }
        .gig-card-content p {
            margin: 0;
        }
    </style>
</head>
<body>
<!-- Navbar menu -->
<!-- Same Navbar code as the original file -->

<!-- Main content -->
<div class="container">
    <div class="row">
        <div class="col-lg-9">
            <div class="card" style="padding:20px 20px 5px 20px;margin-top:20px">
                <div class="panel panel-success">
                    <div class="panel-heading"><h3>Tutoring Gigs</h3></div>
                    <div class="panel-body">
                        <div class="gig-container">
                            <?php 
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $title = $row["title"];
                                    $type = $row["type"];
                                    $description = $row["description"];
                                    $e_username = $row["e_username"];
                                    $image = "https://st2.depositphotos.com/1444927/6033/i/450/depositphotos_60339431-stock-photo-test-time.jpg"; // Example image URL

                                    echo '
                                    <div class="gig-card">
                                        <img src="'.$image.'" alt="Gig Image">
                                        <div class="gig-card-content">
                                            <h4>'.$title.'</h4>
                                            <p><strong>Type:</strong> '.$type.'</p>
                                            <p>'.$description.'</p>
                                            <p><strong>Username:</strong> '.$e_username.'</p>
                                            <form action="tutoring.php" method="post">
                                                <input type="hidden" name="jid" value="'.$row["job_id"].'">
                                                <button type="submit" class="btn btn-primary">View Details</button>
                                            </form>
                                        </div>
                                    </div>
                                    ';
                                }
                            } else {
                                echo "<p>No gigs available for Tutoring.</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3">
            <!-- Search Filters -->
            <!-- Same search filter code as the original file -->
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
